# University of Florida Design-Time Configuration Automation Tool for Minimally Configured Security Engine (MCSE)



# Current State of Development
The current release of the tool supports automatic generation of MCSE instances for following configurability features
- Supports user-defined PUF sizes ranging from 256 bits
- Supports inclusion of 13 different IPs from Host
- Supports user-defined scan protection key width ranging from 16 bits
- Supports user-defined Ownership Authentication Key/Lifecycle Authentication Key sizes ranging from 256 bits
- Supports user-defined Lifecycle Transition Key sizes ranging from 256 bits
-Supports user-defined encryption function; currently supports APC and Camellia256

# Relevant Source Code Structure
- "mcse_config.json" is the script for user-defined inputs
- "mcse_configuration.py" is the configurator script for automatic generation of MCSE instances

# Tool Requirements
- Synopsys VCS 


# Automation Tool Simulation Work-flow
```````
 Modiify "mcse_config.json" with preferred input

```````
make clean

```````
make MCSEtest